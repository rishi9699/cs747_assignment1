import argparse
import numpy as np

parser = argparse.ArgumentParser()

parser.add_argument("--instance")
parser.add_argument("--algorithm")
parser.add_argument("--randomSeed")
parser.add_argument("--epsilon")
parser.add_argument("--scale")
parser.add_argument("--threshold")
parser.add_argument("--horizon")

args = parser.parse_args()

def do_eps_greedy(arms, randomSeed, epsilon, horizon):
    lenn=len(arms)
    tot_reward=0
    rng = np.random.default_rng(randomSeed)
    pulls_till_now = np.zeros(lenn, dtype='uint32')
    empirical_means = np.zeros(lenn)
    
    i=0
    while i<horizon:
        if (rng.binomial(1, epsilon))==1:
            arm_index = rng.integers(lenn)
        else:
            arm_index = np.argmax(empirical_means)
            
        curr_pull = rng.binomial(1, arms[arm_index])
        tot_reward+=curr_pull
        empirical_means[arm_index] = (empirical_means[arm_index] * pulls_till_now[arm_index] + curr_pull)/(pulls_till_now[arm_index]+1)
        pulls_till_now[arm_index]+=1
        i+=1
    return (horizon*np.max(arms) - tot_reward)
    
def do_ucb(arms, randomSeed, scale, horizon):

    curr_rew = 0
    tot_reward=0
    rng = np.random.default_rng(randomSeed)
    lenn = len(arms)
    empirical_means = np.zeros(lenn)
    
    i=0
    
    while i<lenn:
        curr_rew = rng.binomial(1, arms[i])
        tot_reward+=curr_rew
        empirical_means[i] = curr_rew
        i+=1
    
    pulls_till_now = np.ones(lenn, dtype='uint32')
    
    while i<horizon:
        ucb = empirical_means + np.sqrt((scale*np.log(i))/pulls_till_now)
        arm_index = np.argmax(ucb)
        
        curr_rew = rng.binomial(1, arms[arm_index])
        tot_reward+=curr_rew
        empirical_means[arm_index] = (empirical_means[arm_index] * pulls_till_now[arm_index] + curr_rew)/(pulls_till_now[arm_index]+1)
        pulls_till_now[arm_index]+=1
    
        i+=1
    return (horizon*np.max(arms) - tot_reward)
    
def do_kl_ucb(arms, randomSeed, horizon):
    tot_reward=0
    lenn=len(arms)
    c=3
    rng = np.random.default_rng(randomSeed)
    empirical_means = np.zeros(lenn)
    pulls_till_now = np.zeros(lenn, dtype='uint32')
    delta = 0.0001
    
    i=0
    while i<max(4, lenn):
        curr_rew = rng.binomial(1, arms[i%lenn])
        tot_reward+=curr_rew
        empirical_means[i%lenn] = (empirical_means[i%lenn] * pulls_till_now[i%lenn] + curr_rew)/(pulls_till_now[i%lenn]+1)
        pulls_till_now[i%lenn]+=1
        i+=1
        
    kl_ucbs = np.zeros(lenn)
    while i<horizon:
        rhs_arms = (np.log(i) + c * np.log(np.log(i)))/pulls_till_now
        
        
        # BEGIN CALCULATION OF q's
        for z in range(lenn):
            rhs = rhs_arms[z]
            p = empirical_means[z]
            
            if p==1:
                q = 1
                
            elif p==0:
                left = p
                right = 1
                
                q_candidate = (p+1)/2
                kldiv = np.log(1/(1-q_candidate))
                
                while abs(kldiv-rhs)>delta:
                    if kldiv<rhs:
                        left = q_candidate
                    else:
                        right = q_candidate
                    q_candidate = (left+right)/2
                    kldiv = np.log(1/(1-q_candidate))
                    
                q = q_candidate
                
            else:
                left = p
                right = 1
                
                q_candidate = (p+1)/2
                kldiv = p*np.log(p/q_candidate) + (1-p)*np.log((1-p)/(1-q_candidate))
                
                while abs(kldiv-rhs)>delta:
                    if kldiv<rhs:
                        left = q_candidate
                    else:
                        right = q_candidate
                    q_candidate = (left+right)/2
                    kldiv = p*np.log(p/q_candidate) + (1-p)*np.log((1-p)/(1-q_candidate))
                    
                q = q_candidate
                
            kl_ucbs[z] = q
            
        arm_index = np.argmax(kl_ucbs)
        curr_rew = rng.binomial(1, arms[arm_index])
        tot_reward+=curr_rew
        empirical_means[arm_index] = (empirical_means[arm_index] * pulls_till_now[arm_index] + curr_rew)/(pulls_till_now[arm_index]+1)
        pulls_till_now[arm_index]+=1
        i+=1
        
    return (horizon*np.max(arms) - tot_reward)
    
def do_thompson(arms, randomSeed, horizon):
    tot_reward=0
    rng = np.random.default_rng(randomSeed)
    lenn = len(arms)
    successesp1 = np.ones(lenn, dtype='uint32')
    failuresp1 = np.ones(lenn, dtype='uint32')
    
    i=0
    while i<horizon:
        arm_index = np.argmax(rng.beta(successesp1, failuresp1))
        if (rng.binomial(1, arms[arm_index]))==1:
            successesp1[arm_index]+=1
            tot_reward+=1
        else:
            failuresp1[arm_index]+=1
        i+=1
    
    return (horizon*np.max(arms) - tot_reward)
    
def do_task3(instances, r_support, randomSeed, horizon):
    arms = instances.shape[0]
    rng = np.random.default_rng(randomSeed)
    pulls_till_now = np.zeros(arms, dtype='uint32')
    empirical_means = np.zeros(arms)
    epsilon=0.1
    
    i=0
    tot_reward = 0
    while i<horizon:
        if (rng.binomial(1, epsilon))==1:
            arm_index = rng.integers(arms)
        else:
            arm_index = np.argmax(empirical_means)
            
        rew_obt = rng.choice(r_support, p=instances[arm_index])
        tot_reward+=rew_obt
        empirical_means[arm_index] = (empirical_means[arm_index] * pulls_till_now[arm_index] + rew_obt)/(pulls_till_now[arm_index]+1)
        pulls_till_now[arm_index]+=1
        i+=1
    
    return (horizon*np.max(np.sum(instances*r_support, axis=1)) - tot_reward)

def do_task4(instances, r_support, randomSeed, threshold, horizon):
    arms = instances.shape[0]
    threshold_index = np.where(r_support>=threshold)[0][0]
    rng = np.random.default_rng(randomSeed)
    pulls_till_now = np.zeros(arms, dtype='uint32')
    thresh_means = np.zeros(arms)
    good_pulls = np.zeros(arms, dtype='uint32')

    epsilon=0.1
    
    i=0
    tot_highs=0
    while i<horizon:
        if (rng.binomial(1, epsilon))==1:
            arm_index = rng.integers(arms)
        else:
            arm_index = np.argmax(thresh_means)
            
        rew_obt = rng.choice(r_support, p=instances[arm_index])
        
        curr_high=0
        if (np.where(r_support == rew_obt)[0][0])>=threshold_index:
            good_pulls[arm_index]+=1
            curr_high = 1
            
        tot_highs+=curr_high
        pulls_till_now[arm_index]+=1
        thresh_means[arm_index] = good_pulls[arm_index]/pulls_till_now[arm_index]
        
        i+=1
    
    return tot_highs
    

if args.algorithm[-2:]=='t1':
    f = open(args.instance)
    arms = f.read()
    arms = np.array(arms.split())
    arms = arms.astype(float)
     
    if args.algorithm=='epsilon-greedy-t1':
        REG = do_eps_greedy(arms, int(args.randomSeed), float(args.epsilon), int(args.horizon))
    elif args.algorithm=='ucb-t1':
        REG = do_ucb(arms, int(args.randomSeed), 2, int(args.horizon))
    elif args.algorithm=='kl-ucb-t1':
        REG = do_kl_ucb(arms, int(args.randomSeed), int(args.horizon))
    elif args.algorithm=='thompson-sampling-t1':
        REG = do_thompson(arms, int(args.randomSeed), int(args.horizon))
        
    string_to_return = args.instance+', '+args.algorithm+', '+args.randomSeed+', '+args.epsilon+', '+args.scale+', '+args.threshold+', '+args.horizon+', '+str(round(REG, 2))+', 0\n'

elif args.algorithm[-2:]=='t2':
    f = open(args.instance)
    arms = f.read()
    arms = np.array(arms.split())
    arms = arms.astype(float)
    
    REG = do_ucb(arms, int(args.randomSeed), float(args.scale), int(args.horizon))
    
    string_to_return = args.instance+', '+args.algorithm+', '+args.randomSeed+', '+args.epsilon+', '+args.scale+', '+args.threshold+', '+args.horizon+', '+str(round(REG, 2))+', 0\n'

elif args.algorithm[-2:]=='t3':
    f = open(args.instance)
    instance_data = f.read()
    instance_data = np.array(instance_data.split('\n'))
    r_support = np.array(instance_data[0].split())
    r_support = r_support.astype(float)
    
    instances = np.zeros((instance_data.shape[0] - 1, len(r_support)))
    i = 1
    
    while i<instance_data.shape[0]:
        temporary = np.array(instance_data[i].split())
        instances[i-1] = temporary.astype(float)
        i+=1
    REG = do_task3(instances, r_support, int(args.randomSeed), int(args.horizon))
    
    string_to_return = args.instance+', '+args.algorithm+', '+args.randomSeed+', '+args.epsilon+', '+args.scale+', '+args.threshold+', '+args.horizon+', '+str(round(REG, 2))+', 0\n'
    
elif args.algorithm[-2:]=='t4':
    f = open(args.instance)
    instance_data = f.read()
    instance_data = np.array(instance_data.split('\n'))
    r_support = np.array(instance_data[0].split())
    r_support = r_support.astype(float)
    
    instances = np.zeros((instance_data.shape[0] - 1, len(r_support)))
    i = 1
    
    while i<instance_data.shape[0]:
        temporary = np.array(instance_data[i].split())
        instances[i-1] = temporary.astype(float)
        i+=1

    HIGHS = do_task4(instances, r_support, int(args.randomSeed), float(args.threshold), int(args.horizon))
    
    string_to_return = args.instance+', '+args.algorithm+', '+args.randomSeed+', '+args.epsilon+', '+args.scale+', '+args.threshold+', '+args.horizon+', 0, '+str(HIGHS)+'\n'

print(string_to_return, end='')
